import { SmartdeployUiPage } from './app.po';

describe('smartdeploy-ui App', () => {
  let page: SmartdeployUiPage;

  beforeEach(() => {
    page = new SmartdeployUiPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
